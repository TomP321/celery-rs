"""The consumers highly-optimized inner loop."""
import errno
import socket

from celery import bootsteps
from celery.exceptions import WorkerLostError
from celery.utils.log import get_logger

from . import state

__all__ = ('asynloop', 'synloop')

# pylint: disable=redefined-outer-name
# We cache globals and attribute lookups, so disable this warning.

logger = get_logger(__name__)


def _quick_drain(connection, timeout=0.1):
    try:
        connection.drain_events(timeout=timeout)
    except Exception as exc:  # pylint: disable=broad-except
        exc_errno = getattr(exc, 'errno', None)
        if exc_errno is not None and exc_errno != errno.EAGAIN:
            raise


def _enable_amqheartbeats(timer, connection, rate=2.0):
    heartbeat_error = [None]

    if not connection:
        return heartbeat_error

    heartbeat = connection.get_heartbeat_interval()  # negotiated
    if not (heartbeat and connection.supports_heartbeats):
        return heartbeat_error

    def tick(rate):
        try:
            connection.heartbeat_check(rate)
        except Exception as e:
            # heartbeat_error is passed by reference can be updated
            # no append here list should be fixed size=1
            heartbeat_error[0] = e

    timer.call_repeatedly(heartbeat / rate, tick, (rate,))
    return heartbeat_error


def _timer_entries(timer):
    return {scheduled.entry for scheduled in timer.queue}


def _cancel_timer_entries(timer, entries):
    # Cancel each entry on its own, so one that fails to cancel does not
    # leave the remaining entries of the connection live.
    for entry in entries:
        try:
            timer.cancel(entry)
        except Exception as exc:  # pylint: disable=broad-except
            logger.exception(
                'Error cancelling hub timer entry %r: %r', entry, exc)


def asynloop(obj, connection, consumer, blueprint, hub, qos,
             heartbeat, clock, hbrate=2.0):
    """Non-blocking event loop."""
    RUN = bootsteps.RUN
    update_qos = qos.update
    errors = connection.connection_errors

    on_task_received = obj.create_task_handler()

    # The consumer records the timer entries that existed before it started
    # connecting, so that the entries registered by the transport when
    # connecting are cancelled along with the ones registered below.
    timer_entries_before = obj.timer_entries_before_start
    if timer_entries_before is None:
        timer_entries_before = _timer_entries(hub.timer)

    heartbeat_error = _enable_amqheartbeats(hub.timer, connection, rate=hbrate)
    dispatcher_heartbeat_error = [None]
    if obj.event_dispatcher:
        dispatcher_heartbeat_error = _enable_amqheartbeats(
            hub.timer, obj.event_dispatcher.connection, rate=hbrate)

    consumer.on_message = on_task_received
    obj.controller.register_with_event_loop(hub)
    obj.register_with_event_loop(hub)
    registered_timer_entries = (
        _timer_entries(hub.timer) - timer_entries_before)
    # The consumer cancels these if the connection fails before the loop
    # below is running (see :meth:`Consumer.start`).
    obj.timer_entries_registered = registered_timer_entries
    consumer.consume()
    obj.on_ready()

    # did_start_ok will verify that pool processes were able to start,
    # but this will only work the first time we start, as
    # maxtasksperchild will mess up metrics.
    if not obj.restart_count and not obj.pool.did_start_ok():
        raise WorkerLostError('Could not start worker processes')

    # consumer.consume() may have prefetched up to our
    # limit - drain an event so we're in a clean state
    # prior to starting our event loop.
    if connection.transport.driver_type == 'amqp':
        hub.call_soon(_quick_drain, connection)

    # FIXME: Use loop.run_forever
    # Tried and works, but no time to test properly before release.
    hub.propagate_errors = errors
    loop = hub.create_loop()

    try:
        while blueprint.state == RUN and obj.connection:
            state.maybe_shutdown()
            if heartbeat_error[0] is not None:
                raise heartbeat_error[0]
            if dispatcher_heartbeat_error[0] is not None:
                raise dispatcher_heartbeat_error[0]

            # We only update QoS when there's no more messages to read.
            # This groups together qos calls, and makes sure that remote
            # control commands will be prioritized over task messages.
            if qos.prev != qos.value:
                update_qos()

            try:
                next(loop)
            except StopIteration:
                loop = hub.create_loop()
    except Exception:
        # Reset the hub on error (e.g. connection loss) to clean up
        # stale file descriptors and callbacks from the old connection.
        # Also cancel the timer entries registered while connecting and
        # starting this loop, so that stale periodic entries (e.g.
        # maybe_restore_messages) do not fire against the broken connection
        # after reconnect and trigger another crash before the new
        # connection is fully established.
        # We intentionally do NOT reset on normal exit (graceful shutdown)
        # so that timers (e.g. heartbeat) keep firing while the pool drains.
        # WorkerShutdown/WorkerTerminate extend SystemExit (not Exception)
        # so they won't be caught here.
        try:
            hub.reset()
        except Exception as exc:  # pylint: disable=broad-except
            logger.exception(
                'Error cleaning up after event loop: %r', exc)
        # These entries are registered again when the consumer reconnects
        # and calls asynloop again; without cancelling them, each reconnect
        # adds another copy.  The timer must not be cleared: it is shared
        # with the rest of the worker, and other entries on it, such as the
        # soft/hard time limits of tasks that keep running across the
        # reconnect, are not registered again (#10888).
        # This runs even if hub.reset() raised above.
        _cancel_timer_entries(hub.timer, registered_timer_entries)
        raise


def synloop(obj, connection, consumer, blueprint, hub, qos,
            heartbeat, clock, hbrate=2.0, **kwargs):
    """Fallback blocking event loop for transports that doesn't support AIO."""
    RUN = bootsteps.RUN
    on_task_received = obj.create_task_handler()
    perform_pending_operations = obj.perform_pending_operations
    heartbeat_error = [None]
    dispatcher_heartbeat_error = [None]
    is_green = getattr(obj.pool, 'is_green', False)
    if is_green:
        heartbeat_error = _enable_amqheartbeats(obj.timer, connection, rate=hbrate)
        if obj.event_dispatcher:
            dispatcher_heartbeat_error = _enable_amqheartbeats(
                obj.timer, obj.event_dispatcher.connection, rate=hbrate)
    consumer.on_message = on_task_received
    consumer.consume()

    obj.on_ready()

    def _loop_cycle():
        """
        Perform one iteration of the blocking event loop.
        """
        if heartbeat_error[0] is not None:
            raise heartbeat_error[0]
        if dispatcher_heartbeat_error[0] is not None:
            raise dispatcher_heartbeat_error[0]
        if qos.prev != qos.value:
            qos.update()
        try:
            perform_pending_operations()
            connection.drain_events(timeout=2.0)
        except socket.timeout:
            pass
        except OSError:
            if blueprint.state == RUN:
                raise
        # drain this connection so broker heartbeats are consumed.
        if is_green and obj.amqheartbeat and obj.event_dispatcher:
            connection_ = obj.event_dispatcher.connection
            if connection_ and connection_.supports_heartbeats:
                try:
                    _quick_drain(obj.event_dispatcher.connection)
                except OSError:
                    if blueprint.state == RUN:
                        raise

    try:
        while blueprint.state == RUN and obj.connection:
            try:
                state.maybe_shutdown()
            finally:
                _loop_cycle()
    except Exception:
        # Reset the hub on error (e.g. connection loss) to clean up
        # stale state from the old connection, matching the cleanup
        # already done in asynloop.  Without this, the synloop
        # (used by gevent/eventlet pools) could leave stale callbacks
        # that prevent consumer re-registration after reconnection.
        # See: https://github.com/celery/celery/issues/9191
        if hub is not None:
            try:
                hub.reset()
            except Exception as exc:  # pylint: disable=broad-except
                logger.exception(
                    'Error cleaning up after sync event loop: %r', exc)
        raise
